#ifndef TARGET_H
#define TARGET_H

#include "G4VUserDetectorConstruction.hh"
#include "globals.hh"

class G4LogicalVolume;
class G4VPhysicalVolume;
class G4Box;
class G4Tubs;
class G4Material;
class ProjectDetectorMessenger;

class Target : public G4VUserDetectorConstruction
{
    public:

        Target();
        ~Target();

        virtual G4VPhysicalVolume* Construct();
        void SetTargetThickness(G4double TargetThickness);
        G4double GetTargetThickness();
        const G4VPhysicalVolume* GetTarget() {return targetblock_phys;}

    private:

        void DefineMaterials();
        void SetupGeometry();
        void SetupDetectors();

        G4bool              Constructed;

        //solid volumes
        G4Box*              experimentalHall_box;
        G4Tubs*             targetblock_box;
        G4Box*              stopblock_box;

        //Logical Volumes      
        G4LogicalVolume*    experimentalHall_log;
        G4LogicalVolume*    targetblock_log;
        G4LogicalVolume*    stopblock_log;

        //Physical Volumes
        G4VPhysicalVolume*  experimentalHall_phys;
        G4VPhysicalVolume*  targetblock_phys;
        G4VPhysicalVolume*  stopblock_phys;

		G4Material*        exphall_material;
		G4Material*        target_material;
		G4Material*        stopblock_material;


        ProjectDetectorMessenger*   detectorMessenger;
        //G4double                    targetthickness;
        G4int                       verboseLevel;

};

#endif // TARGET_H
